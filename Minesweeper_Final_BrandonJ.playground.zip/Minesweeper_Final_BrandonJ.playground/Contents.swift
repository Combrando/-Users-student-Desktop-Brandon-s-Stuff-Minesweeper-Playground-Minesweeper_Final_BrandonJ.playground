import UIKit
// Minesweeper Project
// Created by Brandon Jensen

var str = "Welcome to Minesweeper"

class Minesweeper { // Makes the class Minesweeper

    let mine = "💣" //What will be used to represent a mine
    
    let difficulties = ["Bad Luck Tester", "Easy", "Normal", "Hard", "Bomb Squad", "Don't Bother"] // Strings of difficulty names
    
    let difficulty_mineNums = [1, Int(arc4random_uniform(5) + 10), Int(arc4random_uniform(5) + 15), Int(arc4random_uniform(10) + 20), Int(arc4random_uniform(10) + 30), Int(arc4random_uniform(9) + 90)] // Difficulty number of mines. Set to a random range of values.
    
    var percentOfMines = 0.1 // set the percentage of mines. set to .1 for default testing.
    
    var numberOfMines = 10  // Set the number of mines. Default is 10 for testing.

    var gridx = 10 // The value that will be used to make the table. Represents the length of the square grid in number of tiles
    
    var gridy = 10 // Represents the height of the square grid in number of tiles
    
    var tableArray = [[Any]]() // Makes a multidimensional Array of values. This represents the minesweeper table.
    
    var randomMinePlacement = [Int]() // Makes an array of ints that will represent which coordinates (ones digit is column, tens digit is row. 0 is top left, 99 is bottom right) Mines will be placed upon board placement
    
    func setDifficulty(user_diff: Int) { // Allows the user to set the difficulty based off of a number. If no number is defined, a random difficulty is set
        var temp = user_diff // sets a temporary variable to use in the function. This is because user_diff cannot change.
        if temp < 0 || temp > 5 { // If for some reason the user_diff value is out of range, temp will be set to a random value from 0 to 5.
            temp = Int(arc4random_uniform(6))
        }
        print(temp) // prints temp for testing purposes
        let difficulty = difficulties[temp] // sets the difficulty based off of the difficulties array with index temp
        print(difficulty_mineNums)
        if temp == 0 { // Will set the number of mines to 1 if the difficulty is "Bad Luck Tester". This is because the easiest difficulty will only have one mine in it.
            numberOfMines = 1
        }
        else { // if the difficulty is anything else, it will set a number of mines equal to the size of the grid (in number of tiles) by the percentage defined in the mineNums array (for instance, if there are 200 tiles and the percentage of mines is 24%, then the amount of mines in the grid will equal 48. Will round to nearest whole number.
            percentOfMines = Double(Double(difficulty_mineNums[temp]) / 100)
            print(percentOfMines)
            numberOfMines = Int(Double(gridx * gridy) * percentOfMines)
            print(numberOfMines)
        }
        print("Selected difficulty: \(difficulty)") // Prints the selected difficulty
    }
    
    func mineCoordinates() { // Create the array of coordinates where there will be mines
        var minesPlaced = 0
        var value = 0
        var isAMineThere = false
        repeat { // Creates random values and appends the randomMinePlacement array to contain those values.
            value = Int(arc4random_uniform(UInt32(gridx * gridy)))
            if randomMinePlacement.isEmpty { // If there is no values set in the array yet, add the random value to the array
                randomMinePlacement.append(value)
                minesPlaced += 1
            }
            else {
                for i in 0...randomMinePlacement.count - 1 {
                    if value == randomMinePlacement[i] { // Checks to see if the random value generated already has been generated. If so, then another Mine will not be placed.
                        isAMineThere = true
                    }
                }
                if isAMineThere == false { // If the value was not repeated, then add it to the array
                    randomMinePlacement.append(value)
                    minesPlaced += 1
                }
                else { // Otherwise, make sure to set the boolean to false again to ensure there is no infinite loop.
                    isAMineThere = false
                }
            }
            //print(value) // print for bug testing
        } while minesPlaced < numberOfMines
        randomMinePlacement.sort(){ $0 < $1 }
        print(randomMinePlacement)
    }

   func makeTable() { // Append the multidimestional array to make a square array equal to grid (if grid is //10, //then the multidimensional array will have 10 arrays of 10 values
        for i in 0...gridx - 1 { //Adds the first value
            tableArray.append([0])
            for _ in 1...gridy - 1 { // Adds the other values
                tableArray[i].append(0)
            }
        }
     //print(tableArray) // For testing purposes
    }

    func addMines() { // Adds the mines at the coordinates given by the mineCoordinates function
        var x = 0
        var y = 0
        for i in 0...randomMinePlacement.count - 1 {
            if gridy > gridx {
                x = randomMinePlacement[i] / gridy // rows
                y = randomMinePlacement[i] % gridy // columns
                tableArray[x][y] = mine
            }
            else {
                x = randomMinePlacement[i] / gridy // rows
                y = randomMinePlacement[i] % gridy // columns
                tableArray[x][y] = mine
            }
        }
        //print(tableArray)
    }

     func adjacent() { // Adds 1 to the number in the grid if there is a mine adjacent to a tile next to it (if ////    multiple, add up accordingly)
         var adjacentMines = 0
         for x in 0...gridx - 1 {
             for y in 0...gridy - 1 {
                 if tableArray[x][y] is Int {
                     if x+1 < tableArray.count {
                        if tableArray[x+1][y] is String {
                            adjacentMines += 1
                         }
                     }
    
                     if y+1 < tableArray[x].count {
                         if tableArray[x][y+1] is String {
                             adjacentMines += 1
                         }
                     }
    
                     if x-1 >= 0 {
                         if tableArray[x-1][y] is String {
                             adjacentMines += 1
                         }
                     }
    
                     if y-1 >= 0 {
                         if tableArray[x][y-1] is String {
                             adjacentMines += 1
                         }
                     }
    
                     if x+1 < tableArray.count && y+1 < tableArray[x].count  {
                         if tableArray[x+1][y+1] is String {
                             adjacentMines += 1
                         }
                     }
    
                     if x-1 >= 0 && y-1 >= 0  {
                         if tableArray[x-1][y-1] is String {
                             adjacentMines += 1
                         }
                     }
    
                     if x+1 < tableArray.count && y-1 >= 0 {
                         if tableArray[x+1][y-1] is String {
                             adjacentMines += 1
                         }
                     }
    
                     if x-1 >= 0 && y+1 < tableArray[x].count  {
                         if tableArray[x-1][y+1] is String {
                             adjacentMines += 1
                         }
                     }
                 tableArray[x][y] = adjacentMines
                 }
                 adjacentMines = 0
             }
         }
         //print(tableArray)
     }


   func displayInTable() {
    print("", terminator: "\t\t")
    for y in 0...tableArray[0].count - 1 {
        print(y + 1, terminator: "\t")
    }
    print("\n", terminator: "\t\t")
    for _ in 0...tableArray[0].count - 1 {
        print("_", terminator: "\t")
    }
    print("\n")
    for x in 0...tableArray.count - 1 {
        print(x + 1, "\t|", terminator: "\t")
           for y in 0...tableArray[x].count - 1 {
               print("\(tableArray[x][y])", terminator: "\t")
           }
           print("\n")
       }
   }
}

var table1 = Minesweeper()
table1.setDifficulty(user_diff: 1)
table1.mineCoordinates()
table1.makeTable()
table1.addMines()
table1.adjacent()
table1.displayInTable()

print("\n")

var table2 = Minesweeper()
table2.gridx = 10
table2.gridy = 20
table2.setDifficulty(user_diff: 3)
table2.mineCoordinates()
table2.makeTable()
table2.addMines()
table2.adjacent()
table2.displayInTable()

print("\n")

var table3 = Minesweeper()
table3.setDifficulty(user_diff: 4)
table3.gridx = 20
table3.gridy = 10
table3.mineCoordinates()
table3.makeTable()
table3.addMines()
table3.adjacent()
table3.displayInTable()

print("\n")

var table4 = Minesweeper()
table4.numberOfMines = Int(arc4random_uniform(30)) + 10
table4.gridx = Int(arc4random_uniform(10)) + 15
table4.gridy = Int(arc4random_uniform(10)) + 15
table4.mineCoordinates()
table4.makeTable()
table4.addMines()
table4.adjacent()
table4.displayInTable()

var table5 = Minesweeper()
table5.gridx = Int(arc4random_uniform(10)) + 15
table5.gridy = Int(arc4random_uniform(10)) + 15
table5.setDifficulty(user_diff: 2)
table5.mineCoordinates()
table5.makeTable()
table5.addMines()
table5.adjacent()
table5.displayInTable()

var table6 = Minesweeper()
table6.gridx = 10
table6.gridy = 10
table6.setDifficulty(user_diff: 10)
table6.mineCoordinates()
table6.makeTable()
table6.addMines()
table6.adjacent()
table6.displayInTable()

var table7 = Minesweeper()
table7.gridx = Int(arc4random_uniform(10)) + 15
table7.gridy = Int(arc4random_uniform(10)) + 15
table7.setDifficulty(user_diff: Int(arc4random_uniform(6)))
table7.mineCoordinates()
table7.makeTable()
table7.addMines()
table7.adjacent()
table7.displayInTable()
